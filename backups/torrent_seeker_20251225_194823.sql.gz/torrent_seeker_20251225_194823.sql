--
-- PostgreSQL database dump
--

-- Dumped from database version 15.10 (Homebrew)
-- Dumped by pg_dump version 15.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: items; Type: TABLE; Schema: public; Owner: jeff
--

CREATE TABLE public.items (
    id integer NOT NULL,
    text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone
);


ALTER TABLE public.items OWNER TO jeff;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: jeff
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_id_seq OWNER TO jeff;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeff
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: jeff
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    description text NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.logs OWNER TO jeff;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: jeff
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO jeff;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeff
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: matches; Type: TABLE; Schema: public; Owner: jeff
--

CREATE TABLE public.matches (
    id integer NOT NULL,
    item_id integer NOT NULL,
    matched_text text,
    matched_url text NOT NULL,
    source_site text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    torrent_text character varying(500),
    entities jsonb,
    magnet_link text
);


ALTER TABLE public.matches OWNER TO jeff;

--
-- Name: matches_id_seq; Type: SEQUENCE; Schema: public; Owner: jeff
--

CREATE SEQUENCE public.matches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matches_id_seq OWNER TO jeff;

--
-- Name: matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeff
--

ALTER SEQUENCE public.matches_id_seq OWNED BY public.matches.id;


--
-- Name: urls; Type: TABLE; Schema: public; Owner: jeff
--

CREATE TABLE public.urls (
    id integer NOT NULL,
    url text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    config jsonb,
    display_name text
);


ALTER TABLE public.urls OWNER TO jeff;

--
-- Name: urls_id_seq; Type: SEQUENCE; Schema: public; Owner: jeff
--

CREATE SEQUENCE public.urls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.urls_id_seq OWNER TO jeff;

--
-- Name: urls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeff
--

ALTER SEQUENCE public.urls_id_seq OWNED BY public.urls.id;


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: matches id; Type: DEFAULT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.matches ALTER COLUMN id SET DEFAULT nextval('public.matches_id_seq'::regclass);


--
-- Name: urls id; Type: DEFAULT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.urls ALTER COLUMN id SET DEFAULT nextval('public.urls_id_seq'::regclass);


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: jeff
--

COPY public.items (id, text, created_at, updated_at) FROM stdin;
3	Rental Family	2025-12-25 09:56:49.195419	\N
4	Zodiac Killer Project	2025-12-25 10:06:35.574666	\N
5	Hamnet 2025	2025-12-25 10:06:40.046036	\N
6	The Secret Agent	2025-12-25 10:06:48.041909	\N
7	Tennage Wasteland	2025-12-25 10:06:57.56867	\N
8	Fackham Hall 2025	2025-12-25 10:07:06.707895	\N
9	Happy Holidays 2025	2025-12-25 10:07:11.669314	\N
10	La Grazia 2025	2025-12-25 10:07:20.402266	\N
11	A Private Life 2025	2025-12-25 10:07:28.881841	\N
12	Rosemead 2025	2025-12-25 10:07:35.30882	\N
13	Cover Up	2025-12-25 10:07:43.875915	\N
14	The Housemaid	2025-12-25 10:07:52.093854	\N
15	Is This Thing On 2025	2025-12-25 10:07:58.979764	\N
16	The Voice of Hind Rajab 2025	2025-12-25 10:08:07.497666	\N
17	Dead Man’s Wire 2025	2025-12-25 10:08:18.082498	\N
18	My Undesirable Friends	2025-12-25 10:08:24.349369	\N
19	Peter Hujar's Day	2025-12-25 10:08:30.676008	\N
20	BLKNWS	2025-12-25 10:08:33.277835	\N
21	Suspended Time	2025-12-25 10:08:40.369126	\N
22	Megadoc	2025-12-25 10:08:42.843591	\N
23	Billy Idol Should Be Dead	2025-12-25 10:08:49.93044	\N
24	Resurrection 2025	2025-12-25 10:09:04.099626	\N
25	Israel Palestine on Swedish TV 2025	2025-12-25 10:09:18.963106	\N
26	The Road Between Us 2025	2025-12-25 10:09:29.323068	\N
28	The Fishing Place 2025	2025-12-25 14:20:06.537354	\N
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: jeff
--

COPY public.logs (id, "timestamp", description, success) FROM stdin;
1	2025-12-25 13:22:03.298805	Item 'Rental Family' completed with 0 match(es)	f
2	2025-12-25 13:22:20.441113	Item 'Zodiac Killer Project' completed with 0 match(es)	f
3	2025-12-25 13:22:38.88413	Item 'Hamnet 2025' completed with 0 match(es)	f
4	2025-12-25 13:28:14.963067	Item 'The Secret Agent' completed with 0 match(es)	f
5	2025-12-25 13:28:31.463555	Item 'Tennage Wasteland' completed with 0 match(es)	f
6	2025-12-25 13:28:47.50464	Item 'Fackham Hall 2025' completed with 0 match(es)	f
7	2025-12-25 13:29:04.067492	Item 'Happy Holidays 2025' completed with 0 match(es)	f
8	2025-12-25 13:29:20.859702	Item 'La Grazia 2025' completed with 0 match(es)	f
9	2025-12-25 13:30:53.409474	Item 'A Private Life 2025' completed with 0 match(es)	f
10	2025-12-25 13:31:10.178998	Item 'Rosemead 2025' completed with 0 match(es)	f
11	2025-12-25 13:51:01.245547	Item 'Rental Family' completed with 0 match(es)	f
12	2025-12-25 13:51:18.450753	Item 'Zodiac Killer Project' completed with 0 match(es)	f
13	2025-12-25 13:51:35.698988	Item 'Hamnet 2025' completed with 0 match(es)	f
14	2025-12-25 13:56:44.120771	Item 'The Secret Agent' completed with 0 match(es)	f
15	2025-12-25 13:57:00.758868	Item 'Tennage Wasteland' completed with 0 match(es)	f
16	2025-12-25 13:57:17.53864	Item 'Fackham Hall 2025' completed with 0 match(es)	f
17	2025-12-25 13:57:34.031231	Item 'Happy Holidays 2025' completed with 0 match(es)	f
18	2025-12-25 13:57:50.704615	Item 'La Grazia 2025' completed with 0 match(es)	f
19	2025-12-25 13:59:22.446506	Item 'A Private Life 2025' completed with 0 match(es)	f
20	2025-12-25 13:59:38.949856	Item 'Rosemead 2025' completed with 0 match(es)	f
21	2025-12-25 14:06:39.853233	Item 'Cover Up' completed with 0 match(es)	f
22	2025-12-25 14:12:07.154725	Item 'The Housemaid' completed with 0 match(es)	f
23	2025-12-25 14:12:23.766022	Item 'Is This Thing On 2025' completed with 0 match(es)	f
24	2025-12-25 14:12:40.054031	Item 'The Voice of Hind Rajab 2025' completed with 0 match(es)	f
25	2025-12-25 14:12:57.219525	Item 'Dead Man’s Wire 2025' completed with 0 match(es)	f
26	2025-12-25 14:13:13.727345	Item 'My Undesirable Friends' completed with 0 match(es)	f
27	2025-12-25 14:13:30.521823	Item 'Peter Hujar's Day' completed with 0 match(es)	f
28	2025-12-25 14:13:47.27253	Item 'BLKNWS' completed with 0 match(es)	f
29	2025-12-25 14:14:03.485304	Item 'Suspended Time' completed with 0 match(es)	f
30	2025-12-25 14:14:20.010882	Item 'Megadoc' completed with 0 match(es)	f
31	2025-12-25 14:14:36.450747	Item 'Billy Idol Should Be Dead' completed with 0 match(es)	f
32	2025-12-25 14:18:59.834812	Item 'Resurrection 2025' completed with 0 match(es)	f
33	2025-12-25 14:20:07.070924	Item 'Israel Palestine on Swedish TV 2025' completed with 0 match(es)	f
34	2025-12-25 14:20:24.03405	Item 'The Road Between Us 2025' completed with 0 match(es)	f
35	2025-12-25 14:23:18.4375	Item 'Preparation for the Next Life 2025' completed with 0 match(es)	f
36	2025-12-25 19:14:48.673569	Item 'Rental Family' completed with 0 match(es)	f
37	2025-12-25 19:14:59.154673	Item 'Zodiac Killer Project' completed with 0 match(es)	f
38	2025-12-25 19:15:09.576482	Item 'Hamnet 2025' completed with 0 match(es)	f
39	2025-12-25 19:15:42.153614	Item 'The Secret Agent' completed with 5 match(es)	t
40	2025-12-25 19:15:52.618728	Item 'Tennage Wasteland' completed with 0 match(es)	f
41	2025-12-25 19:16:03.571256	Item 'Fackham Hall 2025' completed with 0 match(es)	f
42	2025-12-25 19:16:14.230353	Item 'Happy Holidays 2025' completed with 0 match(es)	f
43	2025-12-25 19:16:24.758305	Item 'La Grazia 2025' completed with 0 match(es)	f
44	2025-12-25 19:17:44.528078	Item 'A Private Life 2025' completed with 2 match(es)	t
45	2025-12-25 19:17:55.096114	Item 'Rosemead 2025' completed with 0 match(es)	f
46	2025-12-25 19:18:28.486058	Item 'Cover Up' completed with 5 match(es)	t
47	2025-12-25 19:19:04.356741	Item 'The Housemaid' completed with 5 match(es)	t
48	2025-12-25 19:19:14.926424	Item 'Is This Thing On 2025' completed with 0 match(es)	f
49	2025-12-25 19:19:25.287651	Item 'The Voice of Hind Rajab 2025' completed with 0 match(es)	f
50	2025-12-25 19:19:35.907971	Item 'Dead Man’s Wire 2025' completed with 0 match(es)	f
51	2025-12-25 19:19:46.39637	Item 'My Undesirable Friends' completed with 0 match(es)	f
52	2025-12-25 19:19:56.973732	Item 'Peter Hujar's Day' completed with 0 match(es)	f
53	2025-12-25 19:20:07.545871	Item 'BLKNWS' completed with 0 match(es)	f
54	2025-12-25 19:20:18.328252	Item 'Suspended Time' completed with 0 match(es)	f
55	2025-12-25 19:20:29.048282	Item 'Megadoc' completed with 0 match(es)	f
56	2025-12-25 19:20:39.390169	Item 'Billy Idol Should Be Dead' completed with 0 match(es)	f
57	2025-12-25 19:21:14.575972	Item 'Resurrection 2025' completed with 5 match(es)	t
58	2025-12-25 19:21:52.701355	Item 'Israel Palestine on Swedish TV 2025' completed with 5 match(es)	t
59	2025-12-25 19:22:03.220685	Item 'The Road Between Us 2025' completed with 0 match(es)	f
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: jeff
--

COPY public.matches (id, item_id, matched_text, matched_url, source_site, created_at, torrent_text, entities, magnet_link) FROM stdin;
399	14	The Housemaid (2026) [1080p] [WEBRip] [5.1]	https://www.limetorrents.fun/The-Housemaid-%282026%29-%5B1080p%5D-%5BWEBRip%5D-%5B5%201%5D-torrent-19414876.html	LimeTorrents	2025-12-25 19:18:45.059947	The Housemaid (2026) [1080p] [WEBRip] [5.1]	[]	magnet:?xt=urn:btih:E1B2C5A675EE6EF5F4E2B010A147681CA78AA978&dn=The+Housemaid+%282026%29+%5B1080p%5D+%5BWEBRip%5D+%5B5.1%5D&tr=http%3A%2F%2Fsecure.pow7.com%2Fannounce&tr=http%3A%2F%2Ft2.pow7.com%2Fannounce&tr=http%3A%2F%2Ft1.pow7.com%2Fannounce&tr=http%3A%2F%2Fpow7.com%3A80%2Fannounce&tr=http%3A%2F%2Fatrack.pow7.com%2Fannounce&tr=http%3A%2F%2Fp4p.arenabg.com%3A1337%2Fannounce&tr=http%3A%2F%2Fopen.acgtracker.com%3A1096%2Fannounce&tr=http%3A%2F%2Ftracker.dler.org%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.tvunderground.org.ru%3A3218%2Fannounce&tr=http%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Fipv4.tracker.harry.lu%3A80%2Fannounce&tr=udp%3A%2F%2F9.rarbg.com%3A2710%2Fannounce&tr=http%3A%2F%2Ftracker.ex.ua%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Fexodus.desync.com%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.ex.ua%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.tfile.me%2Fannounce&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker1.wasabii.com.tw%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.bittorrent.am%2Fannounce&tr=http%3A%2F%2Fmgtracker.org%3A2710%2Fannounce&tr=udp%3A%2F%2Ftracker.ex.ua%3A80%2Fannounce&tr=http%3A%2F%2Ftracker.flashtorrents.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fmgtracker.org%3A2710%2Fannounce&tr=udp%3A%2F%2Ftracker.flashtorrents.org%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.aletorrenty.pl%3A2710%2Fannounce&tr=http%3A%2F%2Fbt2.careland.com.cn%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.ilibr.org%3A80%2Fannounce&tr=http%3A%2F%2Ftorrent.gresille.org%2Fannounce&tr=udp%3A%2F%2Ftracker.aletorrenty.pl%3A2710%2Fannounce&tr=udp%3A%2F%2Fshadowshq.eddie4.nl%3A6969%2Fannounce&tr=udp%3A%2F%2Fshadowshq.yi.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fexplodie.org%3A6969%2Fannounce&tr=udp%3A%2F%2Feddie4.nl%3A6969%2Fannounce&tr=http%3A%2F%2Fexplodie.org%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.mg64.net%3A6881%2Fannounce&tr=http%3A%2F%2Ftracker2.wasabii.com.tw%3A6969%2Fannounce&tr=http%3A%2F%2Fthetracker.org%3A80%2Fannounce&tr=http%3A%2F%2Fopen.touki.ru%2Fannounce.php&tr=udp%3A%2F%2Ftracker2.indowebster.com%3A6969%2Fannounce&tr=http%3A%2F%2Fretracker.krs-ix.ru%2Fannounce&tr=http%3A%2F%2Ftracker.calculate.ru%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.kicks-ass.net%2Fannounce&tr=http%3A%2F%2Ftracker.baravik.org%3A6970%2Fannounce&tr=udp%3A%2F%2Fbt.xxx-tracker.com%3A2710%2Fannounce&tr=http%3A%2F%2Ftracker1.itzmx.com%3A8080%2Fannounce&tr=http%3A%2F%2Ftracker.skyts.net%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.kuroy.me%3A5944%2Fannounce&tr=http%3A%2F%2Ftracker2.itzmx.com%3A6961%2Fannounce&tr=udp%3A%2F%2Ftracker.dler.org%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker4.piratux.com%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.filetracker.pl%3A8089%2Fannounce&tr=udp%3A%2F%2Fp4p.arenabg.com%3A1337%2Fannounce&tr=udp%3A%2F%2Ftorrent.gresille.org%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftorrentsmd.com%3A8080%2Fannounce&tr=udp%3A%2F%2Ftracker.yoshi210.com%3A6969%2Fannounce&tr=udp%3A%2F%2Fopentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.dutchtracking.nl%2Fannounce&tr=http%3A%2F%2Fopen.lolicon.eu%3A7777%2Fannounce&tr=http%3A%2F%2Ftracker.dutchtracking.com%2Fannounce&tr=udp%3A%2F%2Ftracker.tiny-vps.com%3A6969%2Fannounce&tr=http%3A%2F%2Fp4p.arenabg.ch%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.skyts.net%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.piratepublic.com%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=http%3A%2F%2Fwww.wareztorrent.com%2Fannounce&tr=http%3A%2F%2Fmgtracker.org%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.kuroy.me%3A5944%2Fannounce&tr=http%3A%2F%2F91.218.230.81%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.tiny-vps.com%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.edoardocolombo.eu%3A6969%2Fannounce&tr=udp%3A%2F%2Fopen.stealth.si%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.bittor.pw%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.sktorrent.net%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.yoshi210.com%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.kicks-ass.net%3A80%2Fannounce&tr=udp%3A%2F%2Fzer0day.ch%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.grepler.com%3A6969%2Fannounce&tr=http%3A%2F%2Fbt.pusacg.org%3A8080%2Fannounce&tr=udp%3A%2F%2F178.33.73.26%3A2710%2Fannounce&tr=udp%3A%2F%2F91.218.230.81%3A6969%2Fannounce&tr=udp%3A%2F%2F168.235.67.63%3A6969%2Fannounce&tr=http%3A%2F%2F5.79.83.193%3A2710%2Fannounce&tr=http%3A%2F%2F182.176.139.129%3A6969%2Fannounce&tr=udp%3A%2F%2Fopentor.org%3A2710%2Fannounce&tr=udp%3A%2F%2F109.121.134.121%3A1337%2Fannounce&tr=udp%3A%2F%2F213.163.67.56%3A1337%2Fannounce&tr=http%3A%2F%2F109.121.134.121%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.mg64.net%3A2710%2Fannounce&tr=udp%3A%2F%2Ftracker.filetracker.pl%3A8089%2Fannounce&tr=http%3A%2F%2F85.17.19.180%2Fannounce&tr=http%3A%2F%2Fretracker.krs-ix.ru%3A80%2Fannounce&tr=udp%3A%2F%2F62.212.85.66%3A2710%2Fannounce&tr=udp%3A%2F%2Ftracker.mg64.net%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.eddie4.nl%3A6969%2Fannounce&tr=udp%3A%2F%2F62.138.0.158%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.bittor.pw%3A1337%2Fannounce&tr=http%3A%2F%2Fbt.henbt.com%3A2710%2Fannounce&tr=udp%3A%2F%2F182.176.139.129%3A6969%2Fannounce&tr=udp%3A%2F%2F107.150.14.110%3A6969%2Fannounce&tr=udp%3A%2F%2F191.101.229.236%3A1337%2Fannounce&tr=http%3A%2F%2F173.254.204.71%3A1096%2Fannounce&tr=http%3A%2F%2F178.33.73.26%3A2710%2Fannounce&tr=http%3A%2F%2Ftracker.grepler.com%3A6969%2Fannounce&tr=http%3A%2F%2F213.163.67.56%3A1337%2Fannounce&tr=http%3A%2F%2F107.150.14.110%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.kicks-ass.net%3A80%2Fannounce&tr=http%3A%2F%2F46.4.109.148%3A6969%2Fannounce&tr=https%3A%2F%2Fwww.wareztorrent.com%2Fannounce&tr=http%3A%2F%2F104.28.16.69%2Fannounce&tr=http%3A%2F%2F104.28.1.30%3A8080%2Fannounce&tr=http%3A%2F%2F87.253.152.137%2Fannounce&tr=http%3A%2F%2F188.165.253.109%3A1337%2Fannounce&tr=http%3A%2F%2F51.254.244.161%3A6969%2Fannounce&tr=http%3A%2F%2F185.5.97.139%3A8089%2Fannounce&tr=http%3A%2F%2F194.106.216.222%2Fannounce&tr=http%3A%2F%2F178.175.143.27%2Fannounce&tr=http%3A%2F%2F91.217.91.21%3A3218%2Fannounce&tr=http%3A%2F%2F213.159.215.198%3A6970%2Fannounce&tr=http%3A%2F%2F87.248.186.252%3A8080%2Fannounce&tr=http%3A%2F%2Fretracker.gorcomnet.ru%2Fannounce&tr=http%3A%2F%2F81.200.2.231%2Fannounce&tr=http%3A%2F%2F37.19.5.139%3A6969%2Fannounce&tr=http%3A%2F%2F80.246.243.18%3A6969%2Fannounce&tr=http%3A%2F%2F37.19.5.155%3A6881%2Fannounce&tr=http%3A%2F%2F5.79.249.77%3A6969%2Fannounce&tr=http%3A%2F%2F158.69.146.212%3A7777%2Fannounce&tr=http%3A%2F%2F93.92.64.5%2Fannounce&tr=http%3A%2F%2F91.216.110.47%2Fannounce&tr=http%3A%2F%2F74.82.52.209%3A6969%2Fannounce&tr=http%3A%2F%2F59.36.96.77%3A6969%2Fannounce&tr=http%3A%2F%2F210.244.71.26%3A6969%2Fannounce&tr=http%3A%2F%2F210.244.71.25%3A6969%2Fannounce&tr=http%3A%2F%2F128.199.70.66%3A5944%2Fannounce&tr=http%3A%2F%2F195.123.209.37%3A1337%2Fannounce&tr=http%3A%2F%2F157.7.202.64%3A8080%2Fannounce&tr=http%3A%2F%2F125.227.35.196%3A6969%2Fannounce&tr=http%3A%2F%2F114.55.113.60%3A6969%2Fannounce&tr=udp%3A%2F%2F9.rarbg.me%3A2780%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce&tr=udp%3A%2F%2Fzer0day.to%3A1337%2Fannounce&tr=udp%3A%2F%2F94.23.183.33%3A6969%2Fannounce&tr=udp%3A%2F%2F9.rarbg.to%3A2730%2Fannounce&tr=udp%3A%2F%2Ftracker.pirateparty.gr%3A6969%2Fannounce&tr=udp%3A%2F%2F151.80.120.114%3A2710%2Fannounce&tr=udp%3A%2F%2Fpublic.popcorn-tracker.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fretracker.lanta-net.ru%3A2710%2Fannounce&tr=http%3A%2F%2Ftracker.dutchtracking.nl%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.cyberia.is%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.uw0.xyz%3A6969%2Fannounce&tr=udp%3A%2F%2Fopen.demonii.com%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.ololosh.space%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.dump.cl%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker-udp.gbitt.info%3A80%2Fannounce&tr=udp%3A%2F%2Fretracker01-msk-virt.corbina.net%3A80%2Fannounce&tr=udp%3A%2F%2Fopen.free-tracker.ga%3A6969%2Fannounce&tr=udp%3A%2F%2Fns-1.x-fins.com%3A6969%2Fannounce&tr=udp%3A%2F%2Fleet-tracker.moe%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.open-internet.nl%3A6969%2Fannounce&tr=udp%3A%2F%2Fdenis.stalker.upeer.me%3A6969%2Fannounce
408	25	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	https://bt4gprx.com/magnet/ekj8qR9bJ1Oqj4yXomsEN8JVBg9GSBzIB	BT4G	2025-12-25 19:21:30.823533	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	[]	//downloadtorrentfile.com/hash/8c1d505d408572b320ad7b09cd5352c2ecb8b61c?name=Israel%20Palestine%20on%20Swedish%20TV%201958-1989%20%282025%29%201080p.WEB.h264
409	25	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	https://bt4gprx.com/magnet/r5LJXPJBOD0Lw7lQ1FLZqoKINbWDpMEQ	BT4G	2025-12-25 19:21:36.373213	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	[]	//downloadtorrentfile.com/hash/749512806e88bd96f1b03a58263507a1f3dd6e12?name=Israel%20Palestine%20on%20Swedish%20TV%201958-1989%20%282025%29%201080p.WEB.h264
410	25	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	https://bt4gprx.com/magnet/npZH8vW31oQHbcZw2N9fCcF13WxGSBIVB	BT4G	2025-12-25 19:21:42.035172	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	[]	//downloadtorrentfile.com/hash/7a81f8d864e226556bceceb193887279ad043a15?name=Israel%20Palestine%20on%20Swedish%20TV%201958-1989%20%282025%29%201080p.WEB.h264
411	25	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	https://bt4gprx.com/magnet/7fwUX3Bt9mnW8zO3QzDk5p45YHiGS5HIB	BT4G	2025-12-25 19:21:47.378544	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	[]	//downloadtorrentfile.com/hash/ca1f133ba0632a3ead36e7c2a19820cb9f29d629?name=Israel%20Palestine%20on%20Swedish%20TV%201958-1989%20%282025%29%201080p.WEB.h264
412	25	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	https://bt4gprx.com/magnet/H6mwU7afTAEnnq4IqpZObyqqi9nGSRl6B	BT4G	2025-12-25 19:21:52.695446	Israel Palestine on Swedish TV 1958-1989 (2025) 1080p.WEB.h264	[]	//downloadtorrentfile.com/hash/6c2bfc191fe30121b14b8902e8f3c5f247b640d7?name=Israel%20Palestine%20on%20Swedish%20TV%201958-1989%20%282025%29%201080p.WEB.h264
\.


--
-- Data for Name: urls; Type: TABLE DATA; Schema: public; Owner: jeff
--

COPY public.urls (id, url, created_at, updated_at, config, display_name) FROM stdin;
2	https://bt4gprx.com/	2025-12-24 19:46:47.917641	2025-12-24 20:56:57.533051	{"linkSelector": "a.text-decoration-none", "extractionSteps": [{"action": "clickNewPage", "selector": "a:has-text(\\"Magnet Link\\")"}, {"action": "extract", "selector": "a", "attribute": "href"}], "searchInputSelector": "input[name=\\"q\\"]", "searchButtonSelector": "button[type=\\"submit\\"]"}	BT4G
1	https://www.limetorrents.fun	2025-12-24 19:46:35.296852	2025-12-25 08:36:08.470529	{"linkSelector": "table.table2 td.tdleft div.tt-name a", "searchInputSelector": "input[name=\\"q\\"]", "searchButtonSelector": "input[type=\\"submit\\"]"}	LimeTorrents
\.


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeff
--

SELECT pg_catalog.setval('public.items_id_seq', 28, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeff
--

SELECT pg_catalog.setval('public.logs_id_seq', 59, true);


--
-- Name: matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeff
--

SELECT pg_catalog.setval('public.matches_id_seq', 415, true);


--
-- Name: urls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeff
--

SELECT pg_catalog.setval('public.urls_id_seq', 2, true);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: urls urls_pkey; Type: CONSTRAINT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.urls
    ADD CONSTRAINT urls_pkey PRIMARY KEY (id);


--
-- Name: urls urls_url_key; Type: CONSTRAINT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.urls
    ADD CONSTRAINT urls_url_key UNIQUE (url);


--
-- Name: ux_matches_dedupe; Type: INDEX; Schema: public; Owner: jeff
--

CREATE UNIQUE INDEX ux_matches_dedupe ON public.matches USING btree (item_id, matched_url, source_site);


--
-- Name: matches matches_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeff
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

